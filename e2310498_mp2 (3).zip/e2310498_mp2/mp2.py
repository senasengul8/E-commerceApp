import configparser

from seller import Seller

import psycopg2

from messages import *

import uuid

from datetime import datetime
"""
    Splits given command string by spaces and trims each token.
    Returns token list.
"""
def tokenize_command(command):
    tokens = command.split(" ")
    return [t.strip() for t in tokens]

class Mp2Client:
    def __init__(self, config_filename):

        cfg= configparser.ConfigParser();
        cfg.read(config_filename)
        self.db_conn_params=cfg["postgresql"]
        self.conn = None

    """
        Connects to PostgreSQL database and returns connection object.
    """
    def connect(self):
        self.conn = psycopg2.connect(**self.db_conn_params)
        self.conn.autocommit = False

    """
        Disconnects from PostgreSQL database.
    """
    def disconnect(self):
        self.conn.close()

    """
        Prints list of available commands of the software.
    """
    def help(self):
        # prints the choices for commands and parameters
        print("\n*** Please enter one of the following commands ***")
        print("> help")
        print("> sign_up <seller_id> <subscriber_key> <zip_code> <city> <state> <plan_id>")
        print("> sign_in <seller_id> <subscriber_key>")
        print("> sign_out")
        print("> show_plans")
        print("> show_subscription")
        print("> change_stock <product_id> <add or remove> <amount>")
        print("> show_quota")
        print("> subscribe <plan_id>")
        print("> ship <product_id_1> <product_id_2> <product_id_3> ... <product_id_n>")
        print("> calc_gross")
        print("> show_cart <customer_id>")
        print("> change_cart <customer_id> <product_id> <seller_id> <add or remove> <amount>")
        print("> purchase_cart <customer_id>")
        print("> quit")
    
    """
        Saves seller with given details.
        - Return type is a tuple, 1st element is a boolean and 2nd element is the response message from messages.py.
        - If the operation is successful, commit changes and return tuple (True, CMD_EXECUTION_SUCCESS).
        - If any exception occurs; rollback, do nothing on the database and return tuple (False, CMD_EXECUTION_FAILED).
    """
    def sign_up(self, seller_id, sub_key, zip, city, state, plan_id):
        try:
            # Start a new transaction
            self.conn.autocommit = False
            cursor = self.conn.cursor()

            # Check if the seller already exists
            check_query = f"SELECT COUNT(*) FROM sellers WHERE seller_id = '{seller_id}'"
            cursor.execute(check_query)
            seller_exists = cursor.fetchone()[0] > 0

            if seller_exists:
                return False, SIGNUP_FAILED_EXISTS

            # Insert the new seller into the sellers table
            insert_seller_query = f"INSERT INTO sellers (seller_id,seller_zip_code_prefix, seller_city, seller_state) " \
                                  f"VALUES ('{seller_id}', '{zip}', '{city}', '{state}')"
            cursor.execute(insert_seller_query)

            # Get the seller's ID from the sellers table
            get_seller_id_query = f"SELECT seller_id FROM sellers WHERE seller_id = '{seller_id}'"
            cursor.execute(get_seller_id_query)
            seller_db_id = cursor.fetchone()[0]

            # Insert the seller's subscription into the seller_subscription table
            insert_subscription_query = f"INSERT INTO seller_subscription (seller_id, subscriber_key, session_count, plan_id) " \
                                        f"VALUES ('{seller_db_id}', '{sub_key}', 0, {plan_id})"
            cursor.execute(insert_subscription_query)

            # Commit the changes
            self.conn.commit()

            return True, CMD_EXECUTION_SUCCESS

        except (psycopg2.Error, Exception) as error:
            # Rollback the transaction
            self.conn.rollback()
            print(f"Error executing sign_up: {error}")
            return False, CMD_EXECUTION_FAILED
    """
        Retrieves seller information if seller_id and subscriber_key is correct and seller's session_count < max_parallel_sessions.
        - Return type is a tuple, 1st element is a seller object and 2nd element is the response message from messages.py.
        - If seller_id or subscriber_key is wrong, return tuple (None, USER_SIGNIN_FAILED).
        - If session_count < max_parallel_sessions, commit changes (increment session_count) and return tuple (seller, CMD_EXECUTION_SUCCESS).
        - If session_count >= max_parallel_sessions, return tuple (None, USER_ALL_SESSIONS_ARE_USED).
        - If any exception occurs; rollback, do nothing on the database and return tuple (None, USER_SIGNIN_FAILED).
    """

    def sign_in(self, seller_id, sub_key):
        try:
            # Start a new transaction
            self.conn.autocommit = False
            cursor = self.conn.cursor()

            # Check if the seller's credentials are correct
            select_query = f"SELECT sellers.seller_id, seller_subscription.session_count, seller_subscription.plan_id " \
                           f"FROM sellers " \
                           f"JOIN seller_subscription ON sellers.seller_id = seller_subscription.seller_id " \
                           f"WHERE seller_subscription.seller_id = '{seller_id}' AND seller_subscription.subscriber_key = '{sub_key}'"
            cursor.execute(select_query)
            result = cursor.fetchone()

            if result is None:
                return None, USER_SIGNIN_FAILED

            seller_db_id, session_count, plan_id = result

            # Check if the seller is out of sessions
            select_max_parallel_sessions_query = f"SELECT max_parallel_sessions FROM subscription_plans " \
                                                 f"WHERE plan_id = {plan_id}"
            cursor.execute(select_max_parallel_sessions_query)
            result = cursor.fetchone()

            if result is None:
                return None, USER_SIGNIN_FAILED

            max_parallel_sessions = result[0]

            if session_count >= max_parallel_sessions:
                return None, USER_ALL_SESSIONS_ARE_USED

            # Increment the session count
            update_session_count_query = f"UPDATE seller_subscription SET session_count = session_count + 1 " \
                                         f"WHERE seller_id = '{seller_db_id}'"
            cursor.execute(update_session_count_query)

            # Commit the changes
            self.conn.commit()

            # Return the seller object and success message
            return seller_db_id, CMD_EXECUTION_SUCCESS

        except (psycopg2.Error, Exception) as error:
            # Rollback the transaction
            self.conn.rollback()
            print(f"Error executing sign_in: {error}")
            return None, USER_SIGNIN_FAILED


    """
        Signs out from given seller's account.
        - Return type is a tuple, 1st element is a boolean and 2nd element is the response message from messages.py.
        - Decrement session_count of the seller in the database.
        - If the operation is successful, commit changes and return tuple (True, CMD_EXECUTION_SUCCESS).
        - If any exception occurs; rollback, do nothing on the database and return tuple (False, CMD_EXECUTION_FAILED).
    """
    def sign_out(self, seller):
        try:
            # Check if the seller is valid and authenticated
            if seller is None:
                return False, CMD_EXECUTION_FAILED

            # Start a new transaction
            self.conn.autocommit = False
            cursor = self.conn.cursor()

            # Decrement the session count
            update_session_count_query = f"UPDATE seller_subscription SET session_count = session_count - 1 " \
                                         f"WHERE seller_id = '{seller}'"
            cursor.execute(update_session_count_query)

            # Ensure that the session count does not go below 0
            update_session_count_query = f"UPDATE seller_subscription SET session_count = 0 " \
                                         f"WHERE seller_id ='{seller}' AND session_count < 0"
            cursor.execute(update_session_count_query)

            # Commit the changes
            self.conn.commit()

            # Return success message
            return True, CMD_EXECUTION_SUCCESS

        except (psycopg2.Error, Exception) as error:
            # Rollback the transaction
            self.conn.rollback()
            print(f"Error executing sign_out: {error}")
            return False, CMD_EXECUTION_FAILED

    """
        Quits from program.
        - Return type is a tuple, 1st element is a boolean and 2nd element is the response message from messages.py.
        - Remember to sign authenticated user out first.
        - If the operation is successful, commit changes and return tuple (True, CMD_EXECUTION_SUCCESS).
        - If any exception occurs; rollback, do nothing on the database and return tuple (False, CMD_EXECUTION_FAILED).
    """
    def quit(self, seller):
        try:
            # Sign out the authenticated seller if there is one
            if seller:
                self.sign_out(seller)

            # Commit the changes and close the database connection
            self.conn.commit()
            self.conn.close()

            return True, CMD_EXECUTION_SUCCESS

        except psycopg2.Error as e:
            # Handle any exceptions that occur during the execution of SQL queries
            if self.conn:
                # Rollback the transaction if an exception occurs
                self.conn.rollback()
            return False, CMD_EXECUTION_FAILED


    """
        Retrieves all available plans and prints them.
        - Return type is a tuple, 1st element is a boolean and 2nd element is the response message from messages.py.
        - If the operation is successful; print available plans and return tuple (True, CMD_EXECUTION_SUCCESS).
        - If any exception occurs; return tuple (False, CMD_EXECUTION_FAILED).
        
        Output should be like:
        #|Name|Max Sessions|Max Stocks Per Product
        1|Basic|2|4
        2|Advanced|4|8
        3|Premium|6|12
    """
    def show_plans(self):
        try:
            # Start a new transaction
            self.conn.autocommit = False
            cursor = self.conn.cursor()

            # Execute the SELECT query to retrieve all columns from the subscription plans table
            select_plans_query = "SELECT * FROM subscription_plans"
            cursor.execute(select_plans_query)

            # Fetch all the rows from the result set
            rows = cursor.fetchall()

            # Print the header row
            print("#|Name|Max Sessions|Max Stocks Per Product")

            # Iterate over the fetched rows and print each plan's details
            for row in rows:
                plan_id, name, max_sessions, max_stocks_per_product = row
                print(f"{plan_id}|{name}|{max_sessions}|{max_stocks_per_product}")

            # Commit the transaction
            self.conn.commit()

            # Return success message
            return True, CMD_EXECUTION_SUCCESS

        except (psycopg2.Error, Exception) as error:
            # Rollback the transaction
            self.conn.rollback()
            print(f"Error executing show_plans: {error}")
            return False, CMD_EXECUTION_FAILED

    def show_subscription(self, seller):
        try:
            cursor = self.conn.cursor()

            # Execute the SELECT query to retrieve the subscription details for the seller
            select_subscription_query = """
                SELECT ss.plan_id, sp.plan_name, sp.max_parallel_sessions, sp.max_stock_per_product
                FROM seller_subscription AS ss
                INNER JOIN subscription_plans AS sp ON ss.plan_id = sp.plan_id
                WHERE ss.seller_id = %s
            """
            cursor.execute(select_subscription_query, (seller,))

            # Fetch the rows from the result set
            rows = cursor.fetchall()

            # Print the header row
            print("#|Name|Max Sessions|Max Stocks Per Product")

            for row in rows:
                plan_id, name, max_sessions, max_stocks_per_product = row
                print(f"{plan_id}|{name}|{max_sessions}|{max_stocks_per_product}")

            # Return success message
            return True, CMD_EXECUTION_SUCCESS

        except (psycopg2.Error, Exception) as error:
            print(f"Error executing show_subscription: {error}")
            return False, CMD_EXECUTION_FAILED

    """
        Change stock count of a product.
        - Return type is a tuple, 1st element is a seller object and 2nd element is the response message from messages.py.
        - If target product does not exist on the database, return tuple (False, PRODUCT_NOT_FOUND).
        - If target stock count > current plan's max_stock_per_product, return tuple (False, QUOTA_LIMIT_REACHED).
        - If the operation is successful, commit changes and return tuple (seller, CMD_EXECUTION_SUCCESS).
        - If any exception occurs; rollback, do nothing on the database and return tuple (False, CMD_EXECUTION_FAILED).
    """

    def change_stock(self, seller, product_id,operation_type,change_amount):
        try:
            # Start a new transaction
            self.conn.autocommit = False
            cursor = self.conn.cursor()

            # Retrieve current stock count and max stock per product for the given product_id and seller
            select_stock_query = """
                SELECT ss.stock_count, sp.max_stock_per_product
                FROM seller_stocks ss
                JOIN seller_subscription subs ON ss.seller_id = subs.seller_id
                JOIN subscription_plans sp ON subs.plan_id = sp.plan_id
                WHERE ss.seller_id = %s AND ss.product_id = %s
            """
            cursor.execute(select_stock_query, (seller, product_id))
            row = cursor.fetchone()

            if row is not None:
                current_stock, max_stock_per_product = row

                # Determine the new stock count based on the operation type and amount
                if operation_type == 'add':
                    new_stock = current_stock + change_amount
                elif operation_type == 'remove':
                    new_stock = current_stock - change_amount

                # Check if the new stock count is within the limits
                if new_stock < 0 or new_stock > max_stock_per_product:
                    # Rollback the transaction
                    self.conn.rollback()
                    return False, QUOTA_LIMIT_REACHED

                # Update the stock count for the product
                update_stock_query = """
                    UPDATE seller_stocks
                    SET stock_count = %s
                    WHERE seller_id = %s AND product_id = %s
                """
                cursor.execute(update_stock_query, (new_stock, seller, product_id))

                # Commit the transaction
                self.conn.commit()

                # Return success message
                return True, CMD_EXECUTION_SUCCESS

            else:
                # Rollback the transaction
                self.conn.rollback()
                return False, PRODUCT_NOT_FOUND

        except (psycopg2.Error, Exception) as error:
            # Rollback the transaction
            self.conn.rollback()
            print(f"Error executing change_stock: {error}")
            return False, CMD_EXECUTION_FAILED


    """
        Retrieves authenticated seller's remaining quota for stocks and prints it. 
        - Return type is a tuple, 1st element is a boolean and 2nd element is the response message from messages.py.
        - If the operation is successful; print the authenticated seller's quota and return tuple (True, CMD_EXECUTION_SUCCESS).
        - If any exception occurs; return tuple (False, CMD_EXECUTION_FAILED).

        If the seller is subscribed to a plan with max_stock_per_product = 12 and
        the current stock for product 92bf5d2084dfbcb57d9db7838bac5cd0 is 10, then output should be like:
        
        Product Id|Remaining Quota
        92bf5d2084dfbcb57d9db7838bac5cd0|2

        If the seller does not have a stock, print 'Quota limit is not activated yet.'
    """

    def show_quota(self, seller):
        try:
            cursor = self.conn.cursor()

            # Retrieve product_id and stock_count for all products in the seller's stock
            select_stock_query = """
                SELECT ss.product_id, ss.stock_count, sp.max_stock_per_product
                FROM seller_stocks ss
                JOIN seller_subscription ssb ON ss.seller_id = ssb.seller_id
                JOIN subscription_plans sp ON ssb.plan_id = sp.plan_id
                WHERE ss.seller_id = %s
            """
            cursor.execute(select_stock_query, (seller,))
            rows = cursor.fetchall()

            if len(rows) == 0:
                # No rows returned, print 'Quota limit is not activated yet.'
                print("Quota limit is not activated yet.")
                return True, CMD_EXECUTION_SUCCESS

            else:
                print("Product Id|Remaining Quota")
                for row in rows:
                    product_id, stock_count, max_stock_per_product = row

                    # Calculate remaining quota
                    remaining_quota = max_stock_per_product - stock_count

                    # Print product_id and remaining quota
                    print(f"{product_id}|{remaining_quota}")

                # Return success message
                return True, CMD_EXECUTION_SUCCESS

        except (psycopg2.Error, Exception) as error:
            print(f"Error executing show_quota: {error}")
            return False, CMD_EXECUTION_FAILED

    """
        Subscribe authenticated seller to new plan.
        - Return type is a tuple, 1st element is a seller object and 2nd element is the response message from messages.py.
        - If target plan does not exist on the database, return tuple (None, PRODUCT_NOT_FOUND).
        - If the new plan's max_parallel_sessions < current plan's max_parallel_sessions, return tuple (None, SUBSCRIBE_MAX_PARALLEL_SESSIONS_UNAVAILABLE).
        - If the operation is successful, commit changes and return tuple (seller, CMD_EXECUTION_SUCCESS).
        - If any exception occurs; rollback, do nothing on the database and return tuple (None, CMD_EXECUTION_FAILED).
    """

    def subscribe(self, seller, plan_id):
        try:
            # Start a new transaction
            self.conn.autocommit = False
            cursor = self.conn.cursor()

            # Retrieve current plan's details for the authenticated seller
            select_current_plan_query = """
                SELECT sp.plan_id, sp.plan_name, sp.max_parallel_sessions, sp.max_stock_per_product
                FROM seller_subscription AS ss
                INNER JOIN subscription_plans AS sp ON ss.plan_id = sp.plan_id
                WHERE ss.seller_id = %s
            """

            cursor.execute(select_current_plan_query, (seller,))
            current_plan = cursor.fetchone()

            if not current_plan:
                # Current plan not found, return error message
                return None, PRODUCT_NOT_FOUND

            # Retrieve details of the new plan with the given plan_id
            select_new_plan_query = """
                SELECT plan_id, plan_name, max_parallel_sessions, max_stock_per_product
                FROM subscription_plans
                WHERE plan_id = %s
            """
            cursor.execute(select_new_plan_query, (plan_id,))
            new_plan = cursor.fetchone()

            if not new_plan:
                # New plan not found, return error message
                return None, PRODUCT_NOT_FOUND

            current_max_sessions = current_plan[2]
            new_max_sessions = new_plan[2]

            if new_max_sessions < current_max_sessions:
                # New plan's max_parallel_sessions is less than the current plan, return error message
                return None, SUBSCRIBE_MAX_PARALLEL_SESSIONS_UNAVAILABLE

            # Update seller's plan in the database
            update_seller_plan_query = """
                UPDATE seller_subscription
                SET plan_id = %s
                WHERE seller_id = %s
            """
            cursor.execute(update_seller_plan_query, (plan_id, seller))

            # Commit the transaction
            self.conn.commit()

            # Reset autocommit mode
            self.conn.autocommit = True

            # Close the cursor
            cursor.close()

            # Return seller object and success message
            return seller, CMD_EXECUTION_SUCCESS

        except psycopg2.Error as e:
            # Handle any exceptions that occur during the execution of SQL queries
            if self.conn:
                # Rollback the transaction if an exception occurs
                self.conn.rollback()
            return None, CMD_EXECUTION_FAILED

    """
        Change stock amounts for multiple distinct products.
        - Return type is a tuple, 1st element is a boolean and 2nd element is the response message from messages.py.
        - If everything is OK and the operation is successful, return (True, CMD_EXECUTION_SUCCESS).
        - If the operation is successful, commit changes and return tuple (True, CMD_EXECUTION_SUCCESS).
        - If any one of the product ids is incorrect; rollback, do nothing on the database and return tuple (False, CMD_EXECUTION_FAILED).
        - If any one of the products is not in the stock; rollback, do nothing on the database and return tuple (False, CMD_EXECUTION_FAILED).
        - If any exception occurs; rollback, do nothing on the database and return tuple (False, CMD_EXECUTION_FAILED).
    """

    def ship(self, seller, product_ids):
        try:
            cursor = self.conn.cursor()

            # Check if all product ids exist in the seller stocks table
            cursor.execute("SELECT product_id FROM seller_stocks WHERE seller_id = %s", (seller,))
            rowsss=cursor.fetchall()

            existing_product_ids = {row[0] for row in rowsss}
            print(existing_product_ids)
            for product_id in product_ids:
                if product_id not in existing_product_ids:
                    print(product_id)
                    self.conn.rollback()
                    return False, CMD_EXECUTION_FAILED

            # Update stock amounts for the shipped products
            for product_id in product_ids:
                cursor.execute(
                    "UPDATE seller_stocks SET stock_count = stock_count - 1 WHERE seller_id = %s AND product_id = %s",
                    (seller, product_id))

            # Commit the changes
            self.conn.commit()
            return True, CMD_EXECUTION_SUCCESS

        except psycopg2.Error as e:
            # Handle any exceptions that occur during the execution of SQL queries
            if self.conn:
                # Rollback the transaction if an exception occurs
                self.conn.rollback()
            return False, EXECUTION_FAILED
    

    """
        Retrieves the gross income per product category for every month.
        - Return type is a tuple, 1st element is a boolean and 2nd element is the response message from messages.py.
        - If the operation is successful; print the results and return tuple (True, CMD_EXECUTION_SUCCESS).
        - If any exception occurs; return tuple (False, CMD_EXECUTION_FAILED).
        
        Output should be like:
        Gross Income|Year|Month
        123.45|2018|1
        67.8|2018|2
    """

    def calc_gross(self, seller):
        try:
            cursor = self.conn.cursor()

            # Check if the seller has sold any products
            cursor.execute(
                "SELECT COUNT(*) FROM order_items WHERE seller_id = %s",
                (seller,)
            )
            result = cursor.fetchone()
            total_orders = result[0]
            if total_orders == 0:
                print("Gross Income: 0")
                return True, CMD_EXECUTION_SUCCESS

            # Calculate the gross income per month
            cursor.execute(
                "SELECT SUM(price * freight_value) AS gross_income, EXTRACT(YEAR FROM purchase_timestamp) AS year, EXTRACT(MONTH FROM purchase_timestamp) AS month "
                "FROM order_items "
                "WHERE seller_id = %s "
                "GROUP BY year, month",
                (seller,)
            )

            rows = cursor.fetchall()

            # Print the results
            print("Gross Income|Year|Month")
            for row in rows:
                gross_income = row[0]
                year = int(row[1])
                month = int(row[2])
                print(f"{gross_income:.2f}|{year}|{month}")

            return True, CMD_EXECUTION_SUCCESS

        except psycopg2.Error as e:
            # Handle any exceptions that occur during the execution of SQL queries
            if self.conn:
                # Rollback the transaction if an exception occurs
                self.conn.rollback()
            return False, CMD_EXECUTION_FAILED

    """
        Retrieves items on the customer's shopping cart
        - Return type is a tuple, 1st element is a boolean and 2nd element is the response message from messages.py.
        - If the operation is successful; print items on the cart and return tuple (True, CMD_EXECUTION_SUCCESS).
        - If any exception occurs; return tuple (False, CMD_EXECUTION_FAILED).
        
        Output should be like:
        Seller Id|Product Id|Amount
        dd7ddc04e1b6c2c614352b383efe2d36|e5f2d52b802189ee658865ca93d83a8f|2
        5b51032eddd242adc84c38acab88f23d|c777355d18b72b67abbeef9df44fd0fd|3
        df560393f3a51e74553ab94004ba5c87|ac6c3623068f30de03045865e4e10089|1
    """

    def show_cart(self, customer_id):
        try:
            cursor = self.conn.cursor()



            # Retrieve items in the customer's shopping cart
            query = "SELECT seller_id, product_id, amount FROM customer_carts WHERE customer_id = %s"
            cursor.execute(query, (customer_id,))
            cart_items = cursor.fetchall()

            # Print the cart items
            print("Seller Id|Product Id|Amount")
            for item in cart_items:
                print(f"{item[0]}|{item[1]}|{item[2]}")

            return True, CMD_EXECUTION_SUCCESS

        except psycopg2.Error as e:
            # Handle any exceptions that occur during the execution of SQL queries
            if self.conn:
                # Rollback the transaction if an exception occurs
                self.conn.rollback()
            print("ERROR: Failed to execute the command.")
            return False, CMD_EXECUTION_FAILED

    """
        Change count of items in shopping cart
        - Return type is a tuple, 1st element is a seller object and 2nd element is the response message from messages.py.
        - If customer does not exist on the database, return tuple (False, CUSTOMER_NOT_FOUND).
        - If target product does not exist on the database, return tuple (False, PRODUCT_NOT_FOUND).
        - If the operation is successful, commit changes and return tuple (True, CMD_EXECUTION_SUCCESS).
        - If any exception occurs; rollback, do nothing on the database and return tuple (False, CMD_EXECUTION_FAILED).
        - Consider stocks of sellers when you add items to the cart.
    """

    def change_cart(self, customer_id, product_id, seller_id, operation, change_amount):
        try:
            cursor = self.conn.cursor()

            # Get the current amount in the customer's cart for the specified product and seller
            cursor.execute(
                "SELECT amount FROM customer_carts WHERE customer_id = %s AND product_id = %s AND seller_id = %s",
                (customer_id, product_id, seller_id))
            result = cursor.fetchone()

            if result:
                # Item already exists in the cart, update the amount
                current_amount = result[0]
                new_amount = current_amount + change_amount

                if new_amount <= 0:
                    # Remove the entry from the cart if the new amount will be <= 0
                    cursor.execute(
                        "DELETE FROM customer_carts WHERE customer_id = %s AND product_id = %s AND seller_id = %s",
                        (customer_id, product_id, seller_id))
                else:
                    # Update the amount in the cart
                    cursor.execute(
                        "UPDATE customer_carts SET amount = %s WHERE customer_id = %s AND product_id = %s AND seller_id = %s",
                        (new_amount, customer_id, product_id, seller_id))
            else:
                # Item doesn't exist in the cart, add it
                if change_amount > 0:
                    # Check if there are enough stocks available
                    if operation == 'add' and change_amount > product[1]:
                        return False, STOCK_UNAVAILABLE

                    # Add the item to the cart
                    cursor.execute(
                        "INSERT INTO customer_carts (customer_id, product_id, seller_id, amount) VALUES (%s, %s, %s, %s)",
                        (customer_id, product_id, seller_id, change_amount))

            # Commit the changes
            self.conn.commit()
            return True, CMD_EXECUTION_SUCCESS,

        except psycopg2.Error as e:
            # Handle any exceptions that occur during the execution of SQL queries
            if self.conn:
                # Rollback the transaction if an exception occurs
                self.conn.rollback()
            return False, CMD_EXECUTION_FAILED, "ERROR: Can not execute the given command"

    """
        Purchases items on the cart
        - Return type is a tuple, 1st element is a boolean and 2nd element is the response message from messages.py.
        - If the operation is successful; return tuple (True, CMD_EXECUTION_SUCCESS).
        - If any exception occurs; return tuple (False, CMD_EXECUTION_FAILED).
        
        Actions:
        - Change stocks on seller_stocks table
        - Remove entries from customer_carts table
        - Add entries to order_items table
        - Add single entry to order table
    """

    def purchase_cart(self, customer_id):
        try:
            cursor = self.conn.cursor()



            # Get the items in the customer's cart
            cursor.execute(
                "SELECT product_id, seller_id, amount FROM customer_carts WHERE customer_id = %s",
                (customer_id,))
            cart_items = cursor.fetchall()

            # Check if there are enough stocks available for each item
            for item in cart_items:
                product_id = item[0]
                seller_id = item[1]
                amount = item[2]

                cursor.execute(
                    "SELECT stock_count FROM seller_stocks WHERE seller_id = %s AND product_id = %s",
                    (seller_id, product_id))
                stock = cursor.fetchone()

                if not stock or amount > stock[0]:
                    return False, STOCK_UNAVAILABLE

            # Generate a unique order ID
            order_id = str(uuid.uuid4())

            # Get the current timestamp
            purchase_timestamp = datetime.now()

            # Create an entry in the orders table
            cursor.execute(
                "INSERT INTO orders (order_id, customer_id, order_purchase_timestamp) VALUES (%s, %s, %s)",
                (order_id, customer_id, purchase_timestamp))

            # Create entries in the order items table for each item in the cart
            for item in cart_items:
                product_id = item[0]
                seller_id = item[1]
                amount = item[2]

                # Generate a unique order item ID
                order_item_id = str(uuid.uuid4())

                # Update the seller stocks
                cursor.execute(
                    "UPDATE seller_stocks SET stock_count = stock_count - %s WHERE seller_id = %s AND product_id = %s",
                    (amount, seller_id, product_id))

                # Create an entry in the order items table
                cursor.execute(
                    "INSERT INTO order_items (order_id, order_item_id, product_id, seller_id) VALUES (%s, %s, %s, %s)",
                    (order_id, order_item_id, product_id, seller_id))

            # Clear the customer's cart
            cursor.execute("DELETE FROM customer_carts WHERE customer_id = %s", (customer_id,))

            # Commit the changes
            self.conn.commit()

            return True, "OK"

        except psycopg2.Error as e:
            # Handle any exceptions that occur during the execution of SQL queries
            if self.conn:
                # Rollback the transaction if an exception occurs
                self.conn.rollback()
            return False, "ERROR: Can not execute the given command"


